# Wine

This dataset is wine classification by spectrograph.

Train size: 57

Test size: 54

Missing value: No

Number of classses: 2

Time series length: 234

Data donated by Katherine Kemsley and Anthony Bagnall (see [1).

[1] http://www.timeseriesclassification.com/description.php?Dataset=Wine