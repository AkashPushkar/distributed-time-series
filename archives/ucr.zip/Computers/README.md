# Computers

These problems were taken from data recorded as part of government sponsored study called Powering the Nation (see [1]). The intention was to collect behavioural data about how consumers use electricity within the home to help reduce the UK's carbon footprint. The data contain readings from 251 households, sampled in two-minute intervals over a month. Each series is 720 data points in length (24 hours of readings taken every 2 minutes). Classes are Desktop and Laptop devices.

Train size: 250

Test size: 250

Missing value: No

Number of classses: 2

Time series length: 720

Data donated by Jason Lines and Anthony Bagnall (see [1], [2]).

[1] http://www.energysavingtrust.org.uk/taxonomy/term/2488/all/feed/feed

[2] http://www.timeseriesclassification.com/description.php?Dataset=Computers