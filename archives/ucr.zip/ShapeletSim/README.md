# ShapeletSim

*ShapeletSim* is a simulated dataset.

Train size: 20

Test size: 180

Missing value: No

Number of classses: 2

Time series length: 500

Data donated by Jon Hills and Anthony Bagnall (see [1], [2]).

[1] Hills, Jon, et al. "Classification of time series by shapelet transformation." Data Mining and Knowledge Discovery 28.4 (2014): 851-881. URL https://archive.uea.ac.uk/~ajb/Papers/HillsDAMI2013.pdf

[2] http://www.timeseriesclassification.com/description.php?Dataset=ShapeletSim

